import Foundation;

enum GrapeVarities {
    case grenache, mouvedre, syrah, carignan
}

enum Medal {
    case GOLD, SILVER, BRONZE
    
    var icon : String {
      switch self {
      case .GOLD: return "🥇"
      case .SILVER: return "🥈"
      case .BRONZE: return "🥉"
      }
    }
}

struct Wine : Hashable{
    
    let name: String
    let castle: Castle
    let year: Int
    let isOrganic: Bool
    let price: Double
    let urlImage: URL?
    let grapeVarities: Set<GrapeVarities>
    let medal: Optional<Medal>
    
    var note: Double = 10.0
    var comment: String?
    
    static var capacity: Double = 0.0
    
    func description() -> String {
        return "• \(name) - \(castle.nomination) - \(year)"
   }
}

struct Castle : Hashable{
    let name: String
    let department: Int
    
    // GET-only computed property
    var nomination: String {
        get {
            return "\(name) (\(department))"
        }
    }
}

class Cellar {
    
    var wines: Set<Wine>
    
    init(initialWines: Set<Wine> = []){
        wines = initialWines
    }
        
            //ext   int
    func add(_ wine: Wine){
        let result = wines.insert(wine)
        
        if result.inserted{
            print("➕ " + wine.name + " is added");
        }
    }
    
    func remove(_ wine: Wine) {
        if let wineRemoved = wines.remove(wine) {
            print("🗑 " + wineRemoved.name + " is removed");
        }
    }
    
    func showWines(){
        print("👁 Display Cellar")
        if !(wines.isEmpty){
            
            for wine in wines {
                if let constant = wine.medal {
                    print("\(wine.description()) [\(constant.icon)]")
                } else {
                    print(wine.description())
                }
            }
            
        }
    }
    
}

// Static value
Wine.capacity = 75.0

let cellier2018 = Wine(name: "Château neuf du pape", castle: Castle(name: "Cellier des princes", department: 84), year: 2018, isOrganic: false, price: 18.50, urlImage: URL(fileURLWithPath: "https://www.cellierdesprinces.fr/image/millesime/221/gigondas-cellier-des-princes-bouteille-ecomliste.png"), grapeVarities: [GrapeVarities.grenache, GrapeVarities.mouvedre, GrapeVarities.syrah], medal: Medal.GOLD, comment: nil)

let darons2017 = Wine(name: "Les Darons", castle: Castle(name: "BY JEFF CARREL", department: 66), year: 2017, isOrganic: false, price: 8.60, urlImage: URL(fileURLWithPath: "https://www.jeffcarrel.com/templates/yootheme/cache/LES-DARONS-5c797c66.jpeg"), grapeVarities: [GrapeVarities.grenache, GrapeVarities.carignan, GrapeVarities.syrah], medal: nil, comment: nil)

let cellar = Cellar()
cellar.remove(darons2017)

cellar.add(cellier2018)
cellar.add(darons2017)

cellar.showWines()
cellar.remove(darons2017)
cellar.showWines()

